# BM-A011 — Step 3 raw-signal surrogate null v3 common-support R3

R3 is the corrected execution package prepared after BM-A010 found a finite-ensemble meta-null calibration bug in R2. Do not execute R2.

## Frozen production contract
- 19 participants / 38 recordings; exclude 21, 22, 24
- B=1999 per recording per variant
- master seed 20260921
- meta-null draws 100000
- variants: common_phase_run, independent_channel_phase, epochwise_common_phase
- primary statistic: T_cs on common support
- population unit: participant
- raw source: `/content/drive/MyDrive/C fi/ST44_RAW_88_VERIFIED` and frozen receipt

## R3 correction
Observed recording p remains plus-one `(1+exceedances)/(B+1)`. For a surrogate selected as pseudo-observed inside the empirical group meta-null, the correct finite-ensemble leave-one-out p is `#{arr>=t}/B`, because `t` is already counted in the rank. R2 incorrectly added a second +1.

R3 also blocks the run if any recording×variant surrogate acceptance rate falls below 0.99 and adds an explicit finite-ensemble rank self-test. The production audit table is `AUDIT_12X.csv`.

## Execution
Open `BM-A011_STEP3_FULL_RAW_SIGNAL_V3CS_R3_COLAB.ipynb`, run PRE-FLIGHT, then FULL RUN, then POST-RUN VERIFY.

Smoke tests are engineering checks only and are not scientific results.
