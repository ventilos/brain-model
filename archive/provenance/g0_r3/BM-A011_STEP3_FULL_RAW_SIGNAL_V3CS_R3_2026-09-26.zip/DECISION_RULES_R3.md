# BM-A011 / Step 3 R3 — pre-specified decision rules

1. Scope is N2-localized raw-signal falsification only. It does not establish a whole-stage or whole-brain mechanism.
2. Locked holdout: 19 participants / 38 recordings; subjects 21, 22, 24 excluded.
3. Per recording and variant: B=1999, primary statistic `T_cs`, plus-one observed Monte Carlo p `(1+exceedances)/(B+1)`.
4. Group unit: participant. Two nights are combined by Bonferroni `2*min(p1,p2)`, capped at 1. Participants are aggregated with Fisher.
5. Empirical Fisher meta-null uses pseudo-observed finite-ensemble leave-one-out rank p: `#{arr >= t}/B`; the selected surrogate already counts itself. No extra +1 is added at this level.
6. Meta-null draws: 100000. Group empirical p uses plus-one `(1+#{F_null>=F_obs})/(M+1)`.
7. Common-phase robustness claim requires BOTH `common_phase_run` and `epochwise_common_phase` group empirical p < 0.05. If both fail: `NOT_SUPPORTED_UNDER_PRESPECIFIED_COMMON_PHASE_NULLS`; if one passes and one fails: `INCONCLUSIVE_NULL_SENSITIVE`. `independent_channel_phase` is sensitivity only.
8. Surrogate acceptance rate must be >=0.99 for every recording×variant (`B/attempts`). Failure blocks interpretation until investigated.
9. All receipt hashes, code hashes, checkpoint provenance, 12 audits and package validation must pass.
10. No decision threshold or model definition may be changed after inspecting the full-run result; any later variant is explicitly exploratory.
