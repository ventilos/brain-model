#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
import numpy as np

def fisher_from_p(p):
    return -2*np.log(np.clip(p,np.finfo(float).tiny,1.0)).sum(axis=-1)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--B',type=int,default=1999); ap.add_argument('--N',type=int,default=300000); ap.add_argument('--seed',type=int,default=20260926); a=ap.parse_args()
    B,N=a.B,a.N; rng=np.random.default_rng(a.seed)
    # Exact discrete rank model: observed plus-one rank is uniform on 1..B+1 under exchangeability.
    # Pseudo-observed leave-one-out rank is uniform on 1..B. Build 19 subjects x 2 nights.
    chunk=10000; Fobs=[]; Fpseudo=[]
    for start in range(0,N,chunk):
        n=min(chunk,N-start)
        robs=rng.integers(1,B+2,size=(n,19,2))
        rps=rng.integers(1,B+1,size=(n,19,2))
        pobs=robs/(B+1)
        pps=rps/B
        sobs=np.minimum(1.0,2*np.min(pobs,axis=2))
        sps=np.minimum(1.0,2*np.min(pps,axis=2))
        Fobs.append(fisher_from_p(sobs)); Fpseudo.append(fisher_from_p(sps))
    Fobs=np.concatenate(Fobs); Fpseudo=np.concatenate(Fpseudo)
    q95=float(np.quantile(Fpseudo,.95))
    type1=float(np.mean(Fobs>=q95))
    out={'B':B,'N':N,'seed':a.seed,'q95_pseudo':q95,'type1_obs_against_pseudo_q95':type1,'pass':0.047<=type1<=0.053}
    print(json.dumps(out,indent=2))
    if not out['pass']: raise SystemExit(2)
if __name__=='__main__': main()
