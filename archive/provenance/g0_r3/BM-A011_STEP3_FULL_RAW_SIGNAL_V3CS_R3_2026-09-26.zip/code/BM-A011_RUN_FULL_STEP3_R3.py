#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, subprocess, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
PKG=HERE.parent
EXP=json.loads((PKG/'EXPECTED_HASHES.json').read_text())
def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def verify(rel):
    p=PKG/rel; e=EXP['files'][rel]
    if not p.exists(): raise SystemExit(f'MISSING: {p}')
    if p.stat().st_size != e['bytes'] or sha(p)!=e['sha256']:
        raise SystemExit(f'HASH/SIZE FAIL: {rel}')
    print('PASS', rel, sha(p))
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--raw-dir', default='/content/drive/MyDrive/C fi/ST44_RAW_88_VERIFIED')
    ap.add_argument('--out-root', default='/content/drive/MyDrive/Brain_Model/Analyses/BM-A011_STEP3_RAW_NULL_V3CS_R3_RUN')
    ap.add_argument('--dry-run', action='store_true')
    a=ap.parse_args()
    for rel in EXP['files']: verify(rel)
    raw=Path(a.raw_dir); receipt=raw/'ST44_DOWNLOAD_RECEIPT.csv'
    if not raw.is_dir(): raise SystemExit(f'RAW DIR NOT FOUND: {raw}')
    if not receipt.exists(): raise SystemExit(f'RECEIPT NOT FOUND: {receipt}')
    if sha(receipt)!=EXP['files']['input/ST44_DOWNLOAD_RECEIPT.csv']['sha256']:
        raise SystemExit('DRIVE RECEIPT HASH MISMATCH')
    cmd=[sys.executable,str(PKG/'code/BM-A011__CFI_ST44_RAW_SIGNAL_NULL_V3CS_PRODUCTION.py'),
         '--base-runner',str(PKG/'code/BM-A004__CFI_ST44_RAW_SIGNAL_NULL_V3CS_AUDITED.py'),
         '--raw-dir',str(raw),'--receipt',str(receipt),'--out-root',str(Path(a.out_root)),
         '--b','1999','--seed','20260921','--meta-draws','100000',
         '--variants','common_phase_run','independent_channel_phase','epochwise_common_phase']
    print('COMMAND:'); print(' '.join(map(str,cmd)))
    if a.dry_run: return
    subprocess.run(cmd,check=True)
if __name__=='__main__': main()
