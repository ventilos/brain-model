#!/usr/bin/env python3
from __future__ import annotations
import csv, hashlib, json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
EXCLUDE={"MANIFEST.csv","SHA256SUMS.txt"}
def sha256(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def main():
 exp=json.loads((ROOT/'EXPECTED_HASHES.json').read_text())
 for rel,e in exp['files'].items():
  p=ROOT/rel
  if not p.is_file(): raise SystemExit(f'MISSING CORE: {rel}')
  if p.stat().st_size!=int(e['bytes']) or sha256(p)!=e['sha256']: raise SystemExit(f'CORE FAIL: {rel}')
  print('PASS CORE',rel)
 rows=list(csv.DictReader((ROOT/'MANIFEST.csv').open(newline='')))
 listed={r['path'] for r in rows}; actual={str(p.relative_to(ROOT)).replace('\\','/') for p in ROOT.rglob('*') if p.is_file() and str(p.relative_to(ROOT)).replace('\\','/') not in EXCLUDE}
 if listed!=actual: raise SystemExit(f'MANIFEST SET FAIL missing={sorted(actual-listed)} extra={sorted(listed-actual)}')
 for r in rows:
  p=ROOT/r['path']
  if p.stat().st_size!=int(r['bytes']) or sha256(p)!=r['sha256']: raise SystemExit(f'MANIFEST FAIL: {r["path"]}')
 sums={}
 for line in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
  if line.strip():
   h,rel=line.split('  ',1); sums[rel]=h
 if sums!={r['path']:r['sha256'] for r in rows}: raise SystemExit('SHA256SUMS/MANIFEST MISMATCH')
 print(f'PACKAGE_CORE_PASS core={len(exp["files"])} payload={len(rows)}')
if __name__=='__main__': main()
